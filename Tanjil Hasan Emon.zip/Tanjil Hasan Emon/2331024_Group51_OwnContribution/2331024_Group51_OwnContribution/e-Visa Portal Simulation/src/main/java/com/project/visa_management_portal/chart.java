package com.project.visa_management_portal;

import javafx.scene.chart.PieChart;
import javafx.scene.control.Alert;

public class chart
{
    @javafx.fxml.FXML
    private PieChart pieview;

    @javafx.fxml.FXML
    public void initialize() {
    }

    private void showAlert(String title, Alert.AlertType alertType, String message) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }}