package com.project.visa_management_portal;

import com.project.visa_management_portal.tanjil.registeredAgent.modelClass.Client;
import javafx.scene.control.Alert;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;

import java.io.File;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

public class savingAccountController
{
    @javafx.fxml.FXML
    private TextField mbTF;
    @javafx.fxml.FXML
    private TextField irTf;
    @javafx.fxml.FXML
    private TextField balanceTF;
    @javafx.fxml.FXML
    private ComboBox <String>scomb;
    @javafx.fxml.FXML
    private TextField acTF;

    @javafx.fxml.FXML
    ArrayList<SavingAccount> sac;
    public void initialize() {
        sac = new ArrayList<>();
        scomb.getItems().addAll("Active", "Deactive");

        int acno = Integer.parseInt(acTF.getText());
        String stat = scomb.getValue();
        int bl = (int) Double.parseDouble(balanceTF.getText());
        int IR = Integer.parseInt(irTf.getText());
        double MB = Double.parseDouble(mbTF.getText());

        SavingAccount sa =new SavingAccount(acno, stat, bl, IR, MB);
        sac.add(sa);




        File file = new File("acc.bin");
        FileOutputStream fos = null;
        ObjectOutputStream oos = null;


        try {
            if (file.exists()) {
                fos = new FileOutputStream(file, true);
                oos = new AppendableObjectOutputStream(fos);
            } else {
                fos = new FileOutputStream(file);
                oos = new ObjectOutputStream(fos);
            }

            for (SavingAccount c : sac) {
                oos.writeObject(c);
            }
            oos.close();

            showAlert("Success", Alert.AlertType.INFORMATION, "Client profile created successfully.");


        } catch (Exception e) {
            showAlert("File Error", Alert.AlertType.ERROR, "An error occurred while saving the client profile.");

        }
    }


    private void showAlert(String title, Alert.AlertType alertType, String message) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }





}


