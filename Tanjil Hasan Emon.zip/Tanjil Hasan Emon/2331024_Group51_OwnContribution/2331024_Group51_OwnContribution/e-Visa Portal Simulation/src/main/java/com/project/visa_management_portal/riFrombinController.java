package com.project.visa_management_portal;

import com.project.visa_management_portal.tanjil.registeredAgent.modelClass.Client;
import javafx.scene.control.Alert;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.ArrayList;

public class riFrombinController
{
    @javafx.fxml.FXML
    private TextField IntRateTF;
    @javafx.fxml.FXML
    private TextField minBalTF;
    @javafx.fxml.FXML
    private TableColumn<SavingAccount ,String> minCol;
    @javafx.fxml.FXML
    private TableView <SavingAccount >tabev;
    @javafx.fxml.FXML
    private TableColumn<SavingAccount ,String> rCol;

    @javafx.fxml.FXML
   // ArrayList<SavingAccount> sac = new ArrayList<>();
    public void initialize() {


        minCol.setCellValueFactory(new PropertyValueFactory<>("minimumBalance"));
        rCol.setCellValueFactory(new PropertyValueFactory<>("interestRatet"));




        ArrayList<SavingAccount> acc = new ArrayList<>();

        FileInputStream fis = null;
        ObjectInputStream ois = null;


        File file = new File("acc.bin");

        try {

            if (file.exists()) {
                fis = new FileInputStream(file);
            } else {
                showAlert("File Not Found", Alert.AlertType.ERROR, "Client applications file does not exist.");
            }

            if (fis != null) ois = new ObjectInputStream(fis);

            while (true) {
                SavingAccount client = (SavingAccount) ois.readObject();
                acc.add(client);
            }
        } catch (IOException | ClassNotFoundException e) {
            try {
                if(ois!=null) ois.close();
            }catch (Exception _) {
                showAlert("File Error", Alert.AlertType.ERROR, "Error closing the file.");
            }
        }

        ArrayList<SavingAccount> Updatedacc = new ArrayList<>();

        for (SavingAccount sa : acc){
            if (sa.getInterestRate() == Integer.parseInt(IntRateTF.getText()) && sa.getMinimumBalance() == Double.parseDouble(minBalTF.getText())){
                Updatedacc.add(sa);
            }


        }

        tabev.getItems().addAll(Updatedacc);







    }


    private void showAlert(String title, Alert.AlertType alertType, String message) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

}