package com.project.visa_management_portal;

public class Account {
    protected int accountNumber;
    protected String activeStatus;
    protected double balance;


    public Account(int accountNumber, String activeStatus, double balance) {
        this.accountNumber = accountNumber;
        this.activeStatus = activeStatus;
        this.balance = balance;
    }


    public int getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(int accountNumber) {
        this.accountNumber = accountNumber;
    }

    public String getActiveStatus() {
        return activeStatus;
    }

    public void setActiveStatus(String activeStatus) {
        this.activeStatus = activeStatus;
    }

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }

    @Override
    public String toString() {
        return "Account{" +
                "accountNumber=" + accountNumber +
                ", activeStatus='" + activeStatus + '\'' +
                ", balance=" + balance +
                '}';
    }
}
