package com.project.visa_management_portal;

public class SavingAccount extends Account{
    private int interestRate;
    private double minimumBalance;


    public SavingAccount(int accountNumber, String activeStatus, double balance, int interestRate, double minimumBalance) {
        super(accountNumber, activeStatus, balance);
        this.interestRate = interestRate;
        this.minimumBalance = minimumBalance;
    }


    public int getInterestRate() {
        return interestRate;
    }

    public void setInterestRate(int interestRate) {
        this.interestRate = interestRate;
    }

    public double getMinimumBalance() {
        return minimumBalance;
    }

    public void setMinimumBalance(double minimumBalance) {
        this.minimumBalance = minimumBalance;
    }

    @Override
    public String toString() {
        return "SavingAccount{" +
                "interestRate=" + interestRate +
                ", minimumBalance=" + minimumBalance +
                '}';
    }
}
