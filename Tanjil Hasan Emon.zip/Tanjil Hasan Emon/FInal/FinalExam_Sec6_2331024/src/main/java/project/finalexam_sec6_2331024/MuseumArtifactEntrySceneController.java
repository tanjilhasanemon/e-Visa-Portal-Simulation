package project.finalexam_sec6_2331024;

import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import javax.imageio.IIOException;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Objects;
import java.util.SplittableRandom;

public class MuseumArtifactEntrySceneController
{
    @javafx.fxml.FXML
    private DatePicker acquisitionDateLocalDate;
    @javafx.fxml.FXML
    private TextField catalogNumberTextField;
    @javafx.fxml.FXML
    private RadioButton europeRadioButton;
    @javafx.fxml.FXML
    private TextField artifactNameTextField;
    @javafx.fxml.FXML
    private ToggleGroup originToggle;
    @javafx.fxml.FXML
    private CheckBox displayCheckBox;
    @javafx.fxml.FXML
    private RadioButton asiaRadioButton;
    @javafx.fxml.FXML
    private ComboBox <String> periodComboBox;

    @javafx.fxml.FXML
    ArrayList<MuseumArtifact_2331024> artifactsList ;
    public void initialize() {

        artifactsList = new ArrayList<>();

        periodComboBox.getItems().addAll("Ancient" , "Modern" , "Medieval");

        String origin = null ;


        if(asiaRadioButton.isSelected()){
            origin = "Asia";

        }
        if (europeRadioButton.isSelected()){
            origin = "Europe";
        }
    }

    @javafx.fxml.FXML
    public void addOnAction(ActionEvent actionEvent) {


        String isSelect ;
        if (displayCheckBox.isSelected()){
            isSelect = "True";
        }
        else {
            isSelect = "False";
        }

        boolean isunic = true;
        int tar = Integer.parseInt(catalogNumberTextField.getText());

        for (MuseumArtifact_2331024 m : artifactsList){
            if (tar == m.CatalogNumber){
                isunic = false;
            }
        }



        //Validation

        if ((Objects.equals(acquisitionDateLocalDate.getValue(), acquisitionDateLocalDate.getValue().now())) || catalogNumberTextField.getText().isEmpty() || !originToggle.getSelectedToggle().isSelected()||
        artifactNameTextField.getText().isEmpty() || isSelect.equals("False")){
            showAlert(Alert.AlertType.ERROR , "Give Input properly");

            //varification

        } else if (!isunic) {

            showAlert(Alert.AlertType.ERROR , "Give unique catalog no");

        }




        else {
            MuseumArtifact_2331024 ma = new MuseumArtifact_2331024((Integer.parseInt(catalogNumberTextField.getText())) ,
                    artifactNameTextField.getText() , (originToggle.getSelectedToggle().getProperties()).toString(), periodComboBox.getValue() ,
                    isSelect , acquisitionDateLocalDate.getValue());


            artifactsList.add(ma);



            File  file = new File("MuseumArtifacts.bin");
            FileOutputStream fos = null;
            ObjectOutputStream oos = null;


            try {
                if(file.exists()){
                    fos = new FileOutputStream(file , true);
                    oos = new ObjectOutputStream(fos);

                }
                else {
                    fos = new FileOutputStream(file);
                    oos = new ObjectOutputStream(fos);
                }


                for(MuseumArtifact_2331024 m : artifactsList){
                    oos.writeObject(m);
                }
                oos.close();
            }
            catch (Exception e){
                //
            }

        }


    }

    @javafx.fxml.FXML
    public void nextPageOnAction(ActionEvent actionEvent) throws IOException {


        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("/project/finalexam_sec6_2331024/MuseumArtifactsLoadScene_2331024.fxml"));
        Scene scene = new Scene(fxmlLoader.load());
        Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow() ;
        stage.setTitle("Hello!");
        stage.setScene(scene);
        stage.show();
    }


    public void showAlert(Alert.AlertType type , String msg){
        Alert alert = new Alert(type);
        alert.showAndWait();
        alert.setTitle("Errorooro");
        alert.setContentText(msg);
    }


}