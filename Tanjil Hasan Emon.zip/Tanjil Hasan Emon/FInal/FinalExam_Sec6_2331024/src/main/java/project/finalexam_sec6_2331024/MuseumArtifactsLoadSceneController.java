package project.finalexam_sec6_2331024;

import javafx.event.ActionEvent;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;

import java.io.File;
import java.io.FileInputStream;
import java.io.ObjectInputStream;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Locale;

public class MuseumArtifactsLoadSceneController
{
    @javafx.fxml.FXML
    private TableColumn <MuseumArtifact_2331024 , String> statusTableColumn;
    @javafx.fxml.FXML
    private TableColumn <MuseumArtifact_2331024 , Integer>  catalogNumberTableColumn;
    @javafx.fxml.FXML
    private TableColumn <MuseumArtifact_2331024 , String>periodTableColumn;
    @javafx.fxml.FXML
    private CheckBox filterdisplayCheckBox;
    @javafx.fxml.FXML
    private TableColumn  <MuseumArtifact_2331024 , String>originTableColumn;
    @javafx.fxml.FXML
    private ComboBox <String>filterPeriodComboBox;
    @javafx.fxml.FXML
    private TableView<MuseumArtifact_2331024> artifactTableView;
    @javafx.fxml.FXML
    private TableColumn <MuseumArtifact_2331024 , String>artifactNameTableColumn;
    @javafx.fxml.FXML
    private TableColumn<MuseumArtifact_2331024 , LocalDate> AcquisitionDateTableColumn;

    @javafx.fxml.FXML
    ArrayList<MuseumArtifact_2331024> fileredlist ;

    public void initialize() {
        fileredlist = new ArrayList<>();


        filterPeriodComboBox.getItems().addAll("Ancient" , "Modern" , "Medieval");





        artifactNameTableColumn.setCellValueFactory(new PropertyValueFactory<>("artifactName"));
        catalogNumberTableColumn.setCellValueFactory(new PropertyValueFactory<>("catalogNumber"));
        originTableColumn.setCellValueFactory(new PropertyValueFactory<>("origin"));
        periodTableColumn.setCellValueFactory(new PropertyValueFactory<>("period"));
        statusTableColumn.setCellValueFactory(new PropertyValueFactory<>("displayStatus"));
        AcquisitionDateTableColumn.setCellValueFactory(new PropertyValueFactory<>("acquisitionDate"));



        File file = new File("MuseumArtifacts.bin");

        FileInputStream fis = null;
        ObjectInputStream ois = null;


        try {
            if (file.exists()){
                fis = new FileInputStream(file);
            }

            if (fis != null){
                ois = new ObjectInputStream(fis);
            }


            while (true){
                assert ois != null;
                MuseumArtifact_2331024 m = (MuseumArtifact_2331024) ois.readObject();

                fileredlist.add(m);
            }



        }
        catch (Exception e){
            try {

                if (ois != null){
                    ois.close();
                }

            }
            catch (Exception _){
                //
            }
                //
        }







    }


    @javafx.fxml.FXML
    public void loadOnAction(ActionEvent actionEvent) {

        String filterP = filterPeriodComboBox.getValue();
        boolean disS = false;

        if (filterdisplayCheckBox.isSelected()){
            disS = true;

        }

        ArrayList<MuseumArtifact_2331024> finalFilterlist = new ArrayList<>();


        for (MuseumArtifact_2331024 m : fileredlist){
            if (disS == true & m.getPeriod() == filterP){
                finalFilterlist.add(m);
            }

        }


        artifactTableView.getItems().addAll(finalFilterlist);







    }
}