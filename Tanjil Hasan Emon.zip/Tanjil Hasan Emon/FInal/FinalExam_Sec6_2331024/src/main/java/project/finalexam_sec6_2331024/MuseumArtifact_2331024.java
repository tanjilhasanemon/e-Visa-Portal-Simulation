package project.finalexam_sec6_2331024;

import java.io.Serializable;
import java.time.LocalDate;

public class MuseumArtifact_2331024 implements Serializable {

    public int CatalogNumber;
    public String ArtifactName , Origin , Period , DisplayStatus;
    public LocalDate AcquisitionDate;

    public MuseumArtifact_2331024(int catalogNumber, String artifactName, String origin,
                                  String period, String displayStatus, LocalDate acquisitionDate) {
        CatalogNumber = catalogNumber;
        ArtifactName = artifactName;
        Origin = origin;
        Period = period;
        DisplayStatus = displayStatus;
        AcquisitionDate = acquisitionDate;
    }


    public int getCatalogNumber() {
        return CatalogNumber;
    }

    public void setCatalogNumber(int catalogNumber) {
        CatalogNumber = catalogNumber;
    }

    public String getArtifactName() {
        return ArtifactName;
    }

    public void setArtifactName(String artifactName) {
        ArtifactName = artifactName;
    }

    public String getOrigin() {
        return Origin;
    }

    public void setOrigin(String origin) {
        Origin = origin;
    }

    public String getPeriod() {
        return Period;
    }

    public void setPeriod(String period) {
        Period = period;
    }

    public String getDisplayStatus() {
        return DisplayStatus;
    }

    public void setDisplayStatus(String displayStatus) {
        DisplayStatus = displayStatus;
    }

    public LocalDate getAcquisitionDate() {
        return AcquisitionDate;
    }

    public void setAcquisitionDate(LocalDate acquisitionDate) {
        AcquisitionDate = acquisitionDate;
    }

    @Override
    public String toString() {
        return "MuseumArtifact_2331024{" +
                "CatalogNumber=" + CatalogNumber +
                ", ArtifactName='" + ArtifactName + '\'' +
                ", Origin='" + Origin + '\'' +
                ", Period='" + Period + '\'' +
                ", DisplayStatus='" + DisplayStatus + '\'' +
                ", AcquisitionDate=" + AcquisitionDate +
                '}';
    }


    public int getAcquisitionYear(){
        return AcquisitionDate.getYear();
    }
}
