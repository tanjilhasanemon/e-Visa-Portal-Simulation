module project.finalexam_sec6_2331024 {
    requires javafx.controls;
    requires javafx.fxml;
    requires javafx.graphics;
    requires java.desktop;


    opens project.finalexam_sec6_2331024 to javafx.fxml;
    exports project.finalexam_sec6_2331024;
}