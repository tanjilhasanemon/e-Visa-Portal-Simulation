package com.project.visa_management_portal.galib;

public class VisaOfficer {
}
