package com.project.visa_management_portal.template;

import javafx.event.ActionEvent;

public class templateTwoController
{

    @javafx.fxml.FXML
    public void initialize() {
    }

    @Deprecated
    public void backToDashboardOnActionButton(ActionEvent actionEvent) {
    }
}