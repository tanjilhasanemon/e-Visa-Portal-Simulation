package com.project.visa_management_portal.template;

public class templateController
{
    @javafx.fxml.FXML
    public void initialize() {
    }}